import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

import com.database.DB;


public class UserScreen extends JFrame {
    private String username;
    private JTable bookTable;
    private DefaultTableModel tableModel;
    private JButton borrowButton, returnButton, historyButton;

    public UserScreen(String username) {
        this.username = username;
        DB.loadConnection();
        setTitle("Library Management System - User");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create the table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Library Books"));

        tableModel = new DefaultTableModel(new Object[]{"ID", "Title", "Author", "Category", "Status"}, 0);
        bookTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(bookTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Create button panel
        JPanel buttonPanel = new JPanel();
        borrowButton = new JButton("Borrow Book");
        returnButton = new JButton("Return Book");
        historyButton = new JButton("View Borrowing History");
        buttonPanel.add(borrowButton);
        buttonPanel.add(returnButton);
        buttonPanel.add(historyButton);

        // Add panels to the frame
        add(tablePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Load books from database
        loadBooks();

        // Add action listeners
        borrowButton.addActionListener(new BorrowBookAction());
        returnButton.addActionListener(new ReturnBookAction());
        historyButton.addActionListener(new ViewHistoryAction());
    }

    private void loadBooks() {
        try (Connection conn = DB.con;
             Statement stmt = conn.createStatement()) {
            String query = "SELECT * FROM books";
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("category"),
                        rs.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private class BorrowBookAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow != -1) {
                int bookId = (int) tableModel.getValueAt(selectedRow, 0);
                String status = (String) tableModel.getValueAt(selectedRow, 4);

                if (status.equals("available")) {
                    try (Connection conn = DB.con) {
                        String query = "INSERT INTO borrowings (user_id, book_id, borrow_date, status) VALUES (?, ?, NOW(), 'borrowed')";
                        PreparedStatement pstmt = conn.prepareStatement(query);
                        pstmt.setInt(1, getUserId(username));
                        pstmt.setInt(2, bookId);
                        pstmt.executeUpdate();

                        String updateQuery = "UPDATE books SET status = 'borrowed' WHERE id = ?";
                        PreparedStatement updateStmt = conn.prepareStatement(updateQuery);
                        updateStmt.setInt(1, bookId);
                        updateStmt.executeUpdate();

                        JOptionPane.showMessageDialog(null, "Book borrowed successfully.");
                        tableModel.setValueAt("borrowed", selectedRow, 4);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Selected book is not available for borrowing.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select a book to borrow.");
            }
        }
    }

    private class ReturnBookAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow != -1) {
                int bookId = (int) tableModel.getValueAt(selectedRow, 0);
                String status = (String) tableModel.getValueAt(selectedRow, 4);

                if (status.equals("borrowed")) {
                    try (Connection conn = DB.con) {
                        String updateQuery = "UPDATE borrowings SET return_date = NOW(), status = 'returned' WHERE book_id = ? AND status = 'borrowed'";
                        PreparedStatement pstmt = conn.prepareStatement(updateQuery);
                        pstmt.setInt(1, bookId);
                        pstmt.executeUpdate();

                        String updateBookQuery = "UPDATE books SET status = 'available' WHERE id = ?";
                        PreparedStatement updateBookStmt = conn.prepareStatement(updateBookQuery);
                        updateBookStmt.setInt(1, bookId);
                        updateBookStmt.executeUpdate();

                        JOptionPane.showMessageDialog(null, "Book returned successfully.");
                        tableModel.setValueAt("available", selectedRow, 4);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Selected book is not borrowed.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select a book to return.");
            }
        }
    }

    private class ViewHistoryAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Implement history viewing
            JOptionPane.showMessageDialog(null, "Viewing borrowing history is not implemented yet.");
        }
    }

    private int getUserId(String username) {
        int userId = -1;

        try (Connection conn = DB.con;
             Statement stmt = conn.createStatement()) {
            String query = "SELECT id FROM users WHERE username = '" + username + "'";
            ResultSet rs = stmt.executeQuery(query);

            if (rs.next()) {
                userId = rs.getInt("id");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return userId;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new UserScreen("user1").setVisible(true);
            }
        });
    }
}
