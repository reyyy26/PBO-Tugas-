import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

import com.database.DB;


public class AdminScreen extends JFrame {
    private JTextField titleField, authorField;
    private JComboBox<String> categoryBox;
    private JRadioButton availableButton, borrowedButton;
    private JButton addButton, editButton, deleteButton;
    private JTable bookTable;
    private DefaultTableModel tableModel;

    public AdminScreen() {
        DB.loadConnection();
        setTitle("Library Management System - Admin");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Create input panel
        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Book Details"));

        inputPanel.add(new JLabel("Title:"));
        titleField = new JTextField();
        inputPanel.add(titleField);

        inputPanel.add(new JLabel("Author:"));
        authorField = new JTextField();
        inputPanel.add(authorField);

        inputPanel.add(new JLabel("Category:"));
        categoryBox = new JComboBox<>(new String[]{"Fiction", "Science", "Biography", "History"});
        inputPanel.add(categoryBox);

        inputPanel.add(new JLabel("Status:"));
        ButtonGroup statusGroup = new ButtonGroup();
        availableButton = new JRadioButton("Available", true);
        borrowedButton = new JRadioButton("Borrowed");
        statusGroup.add(availableButton);
        statusGroup.add(borrowedButton);
        JPanel statusPanel = new JPanel(new GridLayout(1, 2));
        statusPanel.add(availableButton);
        statusPanel.add(borrowedButton);
        inputPanel.add(statusPanel);

        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        inputPanel.add(addButton);
        inputPanel.add(editButton);
        inputPanel.add(deleteButton);

        // Create table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Library Books"));

        tableModel = new DefaultTableModel(new Object[]{"ID", "Title", "Author", "Category", "Status"}, 0);
        bookTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(bookTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Add panels to the frame
        add(inputPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);

        // Load books from database
        loadBooks();

        // Add action listeners
        addButton.addActionListener(new AddBookAction());
        editButton.addActionListener(new EditBookAction());
        deleteButton.addActionListener(new DeleteBookAction());
    }

    private void loadBooks() {
        try (Connection conn = DB.con;
             Statement stmt = conn.createStatement()) {
            String query = "SELECT * FROM books";
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("author"),
                        rs.getString("category"),
                        rs.getString("status")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private class AddBookAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String title = titleField.getText();
            String author = authorField.getText();
            String category = (String) categoryBox.getSelectedItem();
            String status = availableButton.isSelected() ? "available" : "borrowed";

            try (Connection conn = DB.con) {
                String query = "INSERT INTO books (title, author, category, status) VALUES (?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(query);
                pstmt.setString(1, title);
                pstmt.setString(2, author);
                pstmt.setString(3, category);
                pstmt.setString(4, status);
                pstmt.executeUpdate();
                tableModel.addRow(new Object[]{tableModel.getRowCount() + 1, title, author, category, status});
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    private class EditBookAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow != -1) {
                int bookId = (int) tableModel.getValueAt(selectedRow, 0);
                String title = titleField.getText();
                String author = authorField.getText();
                String category = (String) categoryBox.getSelectedItem();
                String status = availableButton.isSelected() ? "available" : "borrowed";

                try (Connection conn = DB.con) {
                    String query = "UPDATE books SET title = ?, author = ?, category = ?, status = ? WHERE id = ?";
                    PreparedStatement pstmt = conn.prepareStatement(query);
                    pstmt.setString(1, title);
                    pstmt.setString(2, author);
                    pstmt.setString(3, category);
                    pstmt.setString(4, status);
                    pstmt.setInt(5, bookId);
                    pstmt.executeUpdate();
                    tableModel.setValueAt(title, selectedRow, 1);
                    tableModel.setValueAt(author, selectedRow, 2);
                    tableModel.setValueAt(category, selectedRow, 3);
                    tableModel.setValueAt(status, selectedRow, 4);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    private class DeleteBookAction implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedRow = bookTable.getSelectedRow();
            if (selectedRow != -1) {
                int bookId = (int) tableModel.getValueAt(selectedRow, 0);

                try (Connection conn = DB.con) {
                    String query = "DELETE FROM books WHERE id = ?";
                    PreparedStatement pstmt = conn.prepareStatement(query);
                    pstmt.setInt(1, bookId);
                    pstmt.executeUpdate();
                    tableModel.removeRow(selectedRow);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminScreen().setVisible(true);
            }
        });
    }
}
